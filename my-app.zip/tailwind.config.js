/** @type {import('tailwindcss').Config} */
import {
  fontFamily,
} from "./theme/typography.theme";

module.exports = {
   prefix: 'tw-',
    content: [
      "./src/**/*.{js,jsx,ts,tsx}",
    ],
    theme: {
      fontFamily: fontFamily,
      extend: {},
    },
    plugins: [
        require("tailwindcss"),
        require("autoprefixer"),
    ],
  };
  