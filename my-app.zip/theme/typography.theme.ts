export const fontFamily = {
    family_regular: ["AkkuratPro-regular"],
    family_bold: ["AkkuratPro-Bold"],
    family_light: ["AkkuratPro-light"],
  };