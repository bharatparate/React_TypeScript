import React from 'react';
import ReactDOM from 'react-dom';
import SampleComponent from './components/democomp/DemoComp';
import Component2 from './components/compoenent2/Component2';
import "../src/css/style.scss";

const App = () => <><SampleComponent /> <Component2 /></>;
 
// eslint-disable-next-line react/no-deprecated
ReactDOM.render(<App />, document.getElementById('root'));