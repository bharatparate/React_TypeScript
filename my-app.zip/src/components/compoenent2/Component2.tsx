import React from 'react';
import './Component2.scss';


// Define a functional component named 'SampleComponent' with TypeScript
const Component2: React.FC = () => {
  return (
    <div> 
      <h1>Hello, World!</h1>
      <p>This is a sample React component with TypeScript ewqeqfsfsdfsfdsfswe.</p>
    </div>
  );
};

export default Component2; // Export the component for use in other files