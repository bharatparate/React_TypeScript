import React from 'react';
import './DemoComp.scss';

// Define a functional component named 'SampleComponent' with TypeScript
const SampleComponent: React.FC = () => {
  return ( 
    <div>  
      <h1 className='bharat'>Hello, World!</h1>
      <p className="body-base">This is a sample React component with TypeScript ewqeqfsfsdfsfdsfswe.</p>
   
    </div>
  );
};

export default SampleComponent; // Export the component for use in other files